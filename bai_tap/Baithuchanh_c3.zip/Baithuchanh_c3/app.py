from flask import Flask, render_template, request, jsonify, abort, redirect, url_for, make_response
from sodiem import STUDENTS

app = Flask(__name__)

def calculate_gpa_and_grade(scores):
    """Hàm tính điểm trung bình và xếp loại"""
    if not scores:
        return "-", "-"
    
    avg = sum(scores.values()) / len(scores)
    avg_rounded = round(avg, 2)
    
    if avg_rounded >= 9.0:
        grade = "Xuất sắc"
    elif avg_rounded >= 8.0:
        grade = "Giỏi"
    elif avg_rounded >= 6.5:
        grade = "Khá"
    elif avg_rounded >= 5.0:
        grade = "Trung bình"
    else:
        grade = "Yếu"
        
    return avg_rounded, grade

# -------------------------------------------------------------
# Câu 1. Route Trang chủ ( / )
# -------------------------------------------------------------
@app.route('/')
def index():
    total_students = len(STUDENTS)
    classes = set(student["lop"] for student in STUDENTS.values())
    total_classes = len(classes)
    return render_template('index.html', total_students=total_students, total_classes=total_classes)

# -------------------------------------------------------------
# Câu 2. Route Danh sách sinh viên ( /students )
# -------------------------------------------------------------
@app.route('/students')
def student_list():
    all_classes = sorted(list(set(student["lop"] for student in STUDENTS.values())))
    selected_lop = request.args.get('lop', '').strip()
    
    filtered_students = []
    for mssv, info in STUDENTS.items():
        if selected_lop and info["lop"].upper() != selected_lop.upper():
            continue
                
        dtb, xep_loai = calculate_gpa_and_grade(info["scores"])
        filtered_students.append({
            "mssv": mssv,
            "name": info["name"],
            "lop": info["lop"],
            "dtb": dtb,
            "xep_loai": xep_loai
        })
        
    return render_template('students.html', 
                           students=filtered_students, 
                           classes=all_classes, 
                           selected_lop=selected_lop)

# -------------------------------------------------------------
# Câu 3. Trang chi tiết sinh viên ( /students/<mssv> )
# -------------------------------------------------------------
@app.route('/students/<mssv>')
def student_detail(mssv):
    student = STUDENTS.get(mssv)
    if not student:
        abort(404, description=f"Không có sinh viên với MSSV = {mssv}.")
        
    dtb, xep_loai = calculate_gpa_and_grade(student["scores"])
    return render_template('student_detail.html', mssv=mssv, student=student, dtb=dtb, xep_loai=xep_loai)

# -------------------------------------------------------------
# Route Xuất File CSV ( /students/<mssv>/export )
# -------------------------------------------------------------
@app.route('/students/<mssv>/export')
def export_student_csv(mssv):
    student = STUDENTS.get(mssv)
    
    # MSSV không tồn tại -> Trả về lỗi 404
    if not student:
        abort(404, description=f"Không có sinh viên với MSSV = {mssv}.")
        
    # Tạo nội dung chuỗi CSV với header 'hoc_phan,diem'
    csv_lines = ["hoc_phan,diem"]
    for subject, score in student["scores"].items():
        csv_lines.append(f"{subject},{score}")
    
    csv_content = "\n".join(csv_lines)
    
    # Dùng make_response để tạo HTTP Response và thiết lập Headers cho phép tải xuống
    response = make_response(csv_content)
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = f"attachment; filename=diem_{mssv}.csv"
    
    return response

# -------------------------------------------------------------
# Câu 4. Route chuyển hướng ( /sv/<mssv> ) với mã 301
# -------------------------------------------------------------
@app.route('/sv/<mssv>')
def redirect_student(mssv):
    return redirect(url_for('student_detail', mssv=mssv), code=301)

# -------------------------------------------------------------
# API Route ( /api/students )
# -------------------------------------------------------------
@app.route('/api/students')
def api_students():
    result = []
    for mssv, info in STUDENTS.items():
        dtb, xep_loai = calculate_gpa_and_grade(info["scores"])
        result.append({
            "mssv": mssv,
            "name": info["name"],
            "lop": info["lop"],
            "scores": info["scores"],
            "dtb": dtb,
            "xep_loai": xep_loai
        })
    return jsonify(result)

# -------------------------------------------------------------
# Xử lý trang lỗi 404
# -------------------------------------------------------------
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', description=e.description), 404

if __name__ == '__main__':
    app.run(port=8000, debug=True)