from flask import Flask, render_template, request, jsonify
from sodiem import STUDENTS

app = Flask(__name__)

def calculate_gpa_and_grade(scores):
    """Hàm tính điểm trung bình và xếp loại"""
    if not scores:
        return "-", "-"
    
    avg = sum(scores.values()) / len(scores)
    avg_rounded = round(avg, 2)
    
    if avg_rounded >= 9.0:
        grade = "Xuất sắc"
    elif avg_rounded >= 8.0:
        grade = "Giỏi"
    elif avg_rounded >= 6.5:
        grade = "Khá"
    elif avg_rounded >= 5.0:
        grade = "Trung bình"
    else:
        grade = "Yếu"
        
    return avg_rounded, grade

# -------------------------------------------------------------
# Câu 1. Route Trang chủ ( / )
# -------------------------------------------------------------
@app.route('/')
def index():
    total_students = len(STUDENTS)
    # Lấy danh sách lớp không trùng lặp
    classes = set(student["lop"] for student in STUDENTS.values())
    total_classes = len(classes)
    
    return render_template('index.html', total_students=total_students, total_classes=total_classes)

# -------------------------------------------------------------
# Câu 2. Route Danh sách sinh viên ( /students )
# -------------------------------------------------------------
@app.route('/students')
def student_list():
    # 1. Lấy danh sách các lớp duy nhất từ dữ liệu (không viết cứng)
    all_classes = sorted(list(set(student["lop"] for student in STUDENTS.values())))
    
    # 2. Lấy tham số query ?lop=...
    selected_lop = request.args.get('lop', '').strip()
    
    filtered_students = []
    
    for mssv, info in STUDENTS.items():
        # Lọc lớp không phân biệt hoa thường nếu có query param ?lop=
        if selected_lop:
            if info["lop"].upper() != selected_lop.upper():
                continue
                
        dtb, xep_loai = calculate_gpa_and_grade(info["scores"])
        
        filtered_students.append({
            "mssv": mssv,
            "name": info["name"],
            "lop": info["lop"],
            "dtb": dtb,
            "xep_loai": xep_loai
        })
        
    return render_template('students.html', 
                           students=filtered_students, 
                           classes=all_classes, 
                           selected_lop=selected_lop)

# -------------------------------------------------------------
# Trang chi tiết sinh viên (Dành cho liên kết MSSV)
# -------------------------------------------------------------
@app.route('/students/<mssv>')
def student_detail(mssv):
    student = STUDENTS.get(mssv)
    if not student:
        return "Sinh viên không tồn tại", 404
        
    dtb, xep_loai = calculate_gpa_and_grade(student["scores"])
    return render_template('student_detail.html', mssv=mssv, student=student, dtb=dtb, xep_loai=xep_loai)

# -------------------------------------------------------------
# API Route ( /api/students )
# -------------------------------------------------------------
@app.route('/api/students')
def api_students():
    result = []
    for mssv, info in STUDENTS.items():
        dtb, xep_loai = calculate_gpa_and_grade(info["scores"])
        result.append({
            "mssv": mssv,
            "name": info["name"],
            "lop": info["lop"],
            "scores": info["scores"],
            "dtb": dtb,
            "xep_loai": xep_loai
        })
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)